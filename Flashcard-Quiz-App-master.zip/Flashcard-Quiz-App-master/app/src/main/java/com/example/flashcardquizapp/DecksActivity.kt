package com.example.flashcardquizapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.android.material.floatingactionbutton.FloatingActionButton

class DecksActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: DeckAdapter
    private lateinit var firestore: FirebaseFirestore
    private var decksListener: ListenerRegistration? = null

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_decks)

        firestore = FirebaseFirestore.getInstance()

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = DeckAdapter(mutableListOf())
        recyclerView.adapter = adapter

        findViewById<FloatingActionButton>(R.id.fab_add_deck).setOnClickListener {
            startActivity(Intent(this, AddEditDeckActivity::class.java))
        }

        // Load decks when the activity is created
        loadDecks()

    }

    private fun loadDecks() {
        decksListener = firestore.collection("decks")
            .addSnapshotListener { snapshots, e ->
                if (e != null) {
                    return@addSnapshotListener
                }

                val decks = mutableListOf<Deck>()
                for (doc in snapshots!!) {
                    val deck = doc.toObject(Deck::class.java)
                    deck.id = doc.id
                    decks.add(deck)
                }
                adapter.setDecks(decks)
            }
    }

    override fun onDestroy() {
        super.onDestroy()
        decksListener?.remove()
    }
}