package com.example.flashcardquizapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FlashcardAdapter(private var flashcards: MutableList<Flashcard>) : RecyclerView.Adapter<FlashcardAdapter.FlashcardViewHolder>() {

    inner class FlashcardViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val questionTextView: TextView = itemView.findViewById(R.id.question_text_view)
        private val answerTextView: TextView = itemView.findViewById(R.id.answer_text_view)

        fun bind(flashcard: Flashcard) {
            questionTextView.text = flashcard.question
            answerTextView.text = flashcard.answer
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FlashcardViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_flashcard, parent, false)
        return FlashcardViewHolder(view)
    }

    override fun onBindViewHolder(holder: FlashcardViewHolder, position: Int) {
        val flashcard = flashcards[position]
        holder.bind(flashcard)
    }

    override fun getItemCount() = flashcards.size

    fun setFlashcards(newFlashcards: List<Flashcard>) {
        flashcards = newFlashcards.toMutableList()
        notifyDataSetChanged()
    }
}
