package com.example.flashcardquizapp


import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth


class ForgetPasswordActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forget_password)

        auth = FirebaseAuth.getInstance()

        val emailInput = findViewById<EditText>(R.id.emailInput)
        val resetPasswordButton = findViewById<Button>(R.id.resetPasswordButton)
        val progressBar = findViewById<ProgressBar>(R.id.progressBar)
        val errorText = findViewById<TextView>(R.id.errorText)

        resetPasswordButton.setOnClickListener {
            val email = emailInput.text.toString()
            if (email.isNotEmpty()) {
                progressBar.visibility = View.VISIBLE
                errorText.visibility = View.GONE

                auth.sendPasswordResetEmail(email)
                    .addOnCompleteListener(this) { task ->
                        progressBar.visibility = View.GONE
                        if (task.isSuccessful) {
                            Toast.makeText(this, "Reset email sent", Toast.LENGTH_SHORT).show()
                        } else {
                            val errorMessage = task.exception?.message ?: "Failed to send reset email"
                            errorText.text = errorMessage
                            errorText.visibility = View.VISIBLE
                        }
                    }
            } else {
                errorText.text = "Email cannot be empty"
                errorText.visibility = View.VISIBLE
            }
        }
    }
}
